/*
 * Organize the js similar to how we do in the css
 * folder! Library JS goes into a folder, organized
 * by publisher.
 *
 * This folder is accessible by:
 * http://parkmeister.kaiw.dk/js/
 */
