<?php

define("DBCFG", "/home/groups/parkmeister/parkmeister_config.ini");

?>
