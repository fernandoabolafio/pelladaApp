<?php
	echo "mod_php: It works!\n"
?>
