<?php
	echo "Forcing a change\n";
	echo "mod_php: timm It works!\n";
?>
